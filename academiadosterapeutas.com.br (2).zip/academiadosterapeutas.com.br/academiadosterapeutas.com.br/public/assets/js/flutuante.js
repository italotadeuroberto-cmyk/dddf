function mostra() {
    "flex" == document.getElementById("mostraLigue").style.display ? document.getElementById("mostraLigue").style.display = "none" : document.getElementById("mostraLigue").style.display = "flex"
}